import SwiftUI

extension Color {
    public static var tomato: Color {
        return Color(UIColor(red: 211/255, green: 41/255, blue: 19/255, alpha: 1.0))
    }
}
